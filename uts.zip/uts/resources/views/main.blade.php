@extends ('layout.app')


@section ('title', 'Home Blog')

@section ('content')

<!-- Page Content -->
<div class="container">

  <div class="row">

    <!-- Blog Entries Column -->
    <div class="col-md-8">

      <h1 class="my-4">Daftar Artikel
      </h1>

      <!-- Blog Post -->
      @foreach ( $data as $artikel )


      <div class="card mb-4">
        <div class="card-body">
          <h2 class="card-title">{{$artikel -> title}}</h2>
          <p class="card-text">{{substr ($artikel -> conten, 0, 50) }}</p>
          <a href="{{route ('Blog.show', $loop->index) }}" class="btn btn-primary">Read More &rarr;</a>
        </div>
        <div class="card-footer text-muted">
          Posted on {{ $artikel->datetime }} by {{ $artikel->author }}
        </div>
      </div>
      @endforeach
    </div>



  </div>
  <!-- /.row -->

</div>
<!-- /.container -->
@endsection
