@extends ('layout.app')


@section ('title', $artikel->title)

@section ('content')

<!-- Page Content -->
<div class="container">

  <div class="row">

    <!-- Blog Entries Column -->
    <div class="col-md-12">



      <!-- Blog Post -->
      <div class="card mb-5 my-5">
        <div class="card-body">
          <h1 class="my-4">{{$artikel -> title}}</h1>
          <p class="text-muted">Posted on {{$artikel -> datetime }} by {{$artikel -> author}}</p>
          <p>{{$artikel -> conten}}</p>
        <div class="card-footer ">
            <a href="{{route ('Blog.index') }}" class="btn btn-primary">Kembali</a>
            <a href="{{route ('Blog.edit',$id) }}" class="btn btn-primary">Edit</a>
            <input type="submit" name="" form="formdelete" value="Delete">

        </div>

        </div>
      </div>
    </div>
  </div>
</div>
<form id="formdelete" action="{{ route ('Blog.destroy',$id) }}" method="post">
  @method ('DELETE')
  @csrf
</form>
@endsection
