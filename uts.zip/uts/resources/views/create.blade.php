@extends ('layout.app')


@section ('title', 'Buat Artikel')

@section ('content')

<!-- Page Content -->
<div class="container">

  <div class="row">

    <!-- Blog Entries Column -->
    <div class="col-md-8">

      <h1 class="my-4">Daftar Artikel
      </h1>

      <!-- Blog Post -->
      <div class="card mb-4">
        <div class="card-body">
          <form  action="{{ route ('Blog.store')}}" method="POST">
            @csrf
            <div class="form-group">
              <label for="title">Judul</label>
              <input type="text" class="form-control" name="title" id="title" value="" required"required">
            </div>

            <div class="form-group">
              <label for="title">Author</label>
              <input type="text" class="form-control" name="author" id="author" value="">
            </div>

            <div class="form-group">
              <label for="conten">Konten</label>
              <textarea class="form-control" name="conten" id="conten" rows="10"></textarea>
            </div>
            <input type="submit" class="btn btn-primary" name="" value="Buat Baru">
          </form>
        </div>
      </div>

    </div>



  </div>
  <!-- /.row -->

</div>
<!-- /.container -->
@endsection
