<?php $__env->startSection('title', $artikel->title); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Content -->
<div class="container">

  <div class="row">

    <!-- Blog Entries Column -->
    <div class="col-md-12">



      <!-- Blog Post -->
      <div class="card mb-5 my-5">
        <div class="card-body">
          <h1 class="my-4"><?php echo e($artikel -> title); ?></h1>
          <p class="text-muted">Posted on <?php echo e($artikel -> datetime); ?> by <?php echo e($artikel -> author); ?></p>
          <p><?php echo e($artikel -> conten); ?></p>
        <div class="card-footer ">
            <a href="<?php echo e(route ('Blog.index')); ?>" class="btn btn-primary">Kembali</a>
            <a href="<?php echo e(route ('Blog.edit',$id)); ?>" class="btn btn-primary">Edit</a>
            <input type="submit" name="" form="formdelete" value="Delete">

        </div>

        </div>
      </div>
    </div>
  </div>
</div>
<form id="formdelete" action="<?php echo e(route ('Blog.destroy',$id)); ?>" method="post">
  <?php echo method_field('DELETE'); ?>
  <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uts\resources\views/detail.blade.php ENDPATH**/ ?>