<?php $__env->startSection('title', 'Buat Artikel'); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Content -->
<div class="container">

  <div class="row">

    <!-- Blog Entries Column -->
    <div class="col-md-8">

      <h1 class="my-4">Edit Artikel
      </h1>

      <!-- Blog Post -->
      <div class="card mb-4">
        <div class="card-body">
          <form  action="<?php echo e(route ('Blog.update',$id)); ?>" method="POST">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="title">Judul</label>
              <input type="text" class="form-control" name="title" id="title" value="<?php echo e($artikel -> title); ?>" required"required">
            </div>

            <div class="form-group">
              <label for="title">Author</label>
              <input type="text" class="form-control" name="author" id="author" value="<?php echo e($artikel -> author); ?>">
            </div>

            <div class="form-group">
              <label for="conten" value=>Konten</label>
              <textarea class="form-control" name="conten" id="conten" rows="10"><?php echo e($artikel -> conten); ?></textarea>
            </div>
            <input type="submit" class="btn btn-primary" name="" value="Simpan">
          </form>
        </div>
      </div>

    </div>



  </div>
  <!-- /.row -->

</div>
<!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uts\resources\views/edit.blade.php ENDPATH**/ ?>